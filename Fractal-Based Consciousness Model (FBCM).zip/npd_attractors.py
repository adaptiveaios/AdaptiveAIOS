import numpy as np
import matplotlib.pyplot as plt
from nolds import hurst_rs

# Generate synthetic time series data
np.random.seed(42)
t = np.linspace(0, 100, 1000)

# Healthy cognition (high fractal dimension)
healthy = np.cumsum(np.random.normal(0, 1, 1000))  # Brownian motion (H ≈ 0.7-0.8)

# NPD cognition (rigid, low fractal dimension)
npd = np.sin(0.5 * t) + 0.1 * np.random.normal(0, 1, 1000)  # Periodic with noise (H ≈ 0.5)

# Plot
plt.figure(figsize=(10, 6))
plt.plot(t, healthy, label=f'Healthy (H = {hurst_rs(healthy):.2f})', color='blue', alpha=0.7)
plt.plot(t, npd, label=f'NPD (H = {hurst_rs(npd):.2f})', color='red', alpha=0.7)
plt.xlabel('Time (arbitrary units)')
plt.ylabel('Cognitive State Amplitude')
plt.title('Rigid vs. Adaptive Attractor States (Hurst Exponent $H$)')
plt.legend()
plt.grid(True)
plt.savefig('npd_attractors.png', dpi=300)
plt.show()
