import numpy as np
import matplotlib.pyplot as plt
from nolds import sampen

def multiscale_entropy(data, scales):
    entropy = []
    for scale in scales:
        coarse = np.mean(data[:len(data)//scale * scale].reshape(-1, scale), axis=1)
        entropy.append(sampen(coarse))
    return entropy

# Generate synthetic data
np.random.seed(42)
t = np.linspace(0, 100, 1000)
healthy = np.cumsum(np.random.normal(0, 1, 1000))  # High entropy
npd = np.sin(0.5 * t) + 0.1 * np.random.normal(0, 1, 1000)  # Low entropy

# Compute MSE
scales = np.arange(1, 20)
mse_healthy = multiscale_entropy(healthy, scales)
mse_npd = multiscale_entropy(npd, scales)

# Plot
plt.figure(figsize=(10, 6))
plt.plot(scales, mse_healthy, marker='o', label='Healthy', color='blue')
plt.plot(scales, mse_npd, marker='s', label='NPD', color='red')
plt.xlabel('Time Scale')
plt.ylabel('Sample Entropy ($S_{MSE}$)')
plt.title('Multiscale Entropy Collapse in NPD')
plt.legend()
plt.grid(True)
plt.savefig('entropy_comparison.png', dpi=300)
plt.show()
