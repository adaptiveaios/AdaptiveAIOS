import numpy as np
import matplotlib.pyplot as plt

# Time axis (ages 0 to 25 years)
t = np.linspace(0, 25, 1000)

# Sigmoidal growth for RM (prefrontal cortex development)
gamma_RM = 0.8 * (1 - np.exp(-0.3 * t))  # Sigmoidal curve

# Exponential decay for PD (habit automation)
gamma_AP = 1.2 * np.exp(-0.1 * t)  # Decaying exponential

# Lévy jump intensity (peaking in adolescence)
beta_L = 0.6 * (1 / np.cosh((t - 15) / 3))  # Hyperbolic secant centered at age 15

# Plot
plt.figure(figsize=(10, 6))
plt.plot(t, gamma_RM, label=r'$\gamma_{RM}(t)$ (Reflective Manager)', color='blue', linewidth=2)
plt.plot(t, beta_L, label=r'$\beta_L(t)$ (Lévy Jump Intensity)', color='red', linestyle='--', linewidth=2)
plt.plot(t, gamma_AP, label=r'$\gamma_{AP}(t)$ (Probabilistic Default)', color='green', linestyle=':', linewidth=2)

# Developmental stage annotations
plt.fill_betweenx(y=[0, 1], x1=0, x2=2, color='gray', alpha=0.1, label='Infancy (0–2 yrs)')
plt.fill_betweenx(y=[0, 1], x1=2, x2=4, color='orange', alpha=0.1, label='Early Childhood (2–4 yrs)')
plt.fill_betweenx(y=[0, 1], x1=12, x2=18, color='pink', alpha=0.1, label='Adolescence (12–18 yrs)')

# Labels and styling
plt.xlabel('Age (Years)', fontsize=12)
plt.ylabel('Parameter Value', fontsize=12)
plt.title('Developmental Trajectories of FBCM Parameters', fontsize=14)
plt.legend(loc='upper right', fontsize=10)
plt.grid(True, alpha=0.3)
plt.ylim(0, 1.3)
plt.xlim(0, 25)
plt.savefig('developmental_trajectories.png', dpi=300, bbox_inches='tight')
plt.show()
